<?php
header("Location: ../../");
?>