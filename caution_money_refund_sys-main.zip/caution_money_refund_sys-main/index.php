<?php
header("Location: home.html");
?>